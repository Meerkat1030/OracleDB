<html> 
<head> 
<title>Searching Movie Table</title> 
</head> 
<body> 
<h2>
Searching Movie Table
</h2>
<br>
<form method="post" action="1.php"> 
영화제목에 포함될 단어 : <input type="text" size="20" maxlength="50" name="title"><br> 
상영시간 범위 : <input type="text" size="3" maxlength="3" name="min_length"> - <input type="text" size="3" maxlength="3" name="max_length"><br> 
<input type="text" size="4" maxlength="20" name="birthdate"> 년 이후 태어난 배우가 출연<br>
<br>
<input type="submit" value="submit" name="submit">
</form>
</body>
</html>